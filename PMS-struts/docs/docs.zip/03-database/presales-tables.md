# 售前测试表结构（pm_presales_*）

> 数据库：dppms_d365 (MySQL)  
> 模块：售前项目管理  
> 命名前缀：pm_presales_project_

---

## 1. pm_presales_project_header（售前项目主表）

售前测试项目核心信息表，记录售前测试项目的基本属性和流程状态。

| 字段名 | 类型 | 约束 | 默认值 | 业务含义 |
|--------|------|------|--------|----------|
| presalesId | INT | PK, AUTO_INCREMENT | - | 售前项目主键ID |
| instId | VARCHAR(100) | - | NULL | 流程实例ID（Activiti工作流） |
| applyState | INT | NOT NULL | -1 | 申请状态（-1:草稿 1:审批中 2:审批通过） |
| applyBy | VARCHAR(100) | - | NULL | 申请人编码 |
| applyByName | VARCHAR(100) | - | NULL | 申请人姓名 |
| applyTime | DATETIME | - | NULL | 申请时间 |
| endTime | DATETIME | - | NULL | 项目结束时间 |
| projectState | VARCHAR(10) | NOT NULL | - | 项目状态编码，关联fnd_basic_data |
| projectStates | VARCHAR(100) | - | NULL | 项目状态列表（查询用，逗号分隔） |
| presalesCode | VARCHAR(50) | NOT NULL, UNIQUE | - | 售前项目编码（自动生成） |
| projectCode | VARCHAR(50) | - | NULL | 原项目编码（关联售后项目） |
| projectName | VARCHAR(500) | NOT NULL | - | 项目名称 |
| projectType | VARCHAR(10) | NOT NULL | - | 项目类型（20:售前） |
| marketName | VARCHAR(200) | - | NULL | 市场部 |
| systemName | VARCHAR(200) | - | NULL | 系统部 |
| expendName | VARCHAR(200) | - | NULL | 拓展部 |
| industryName | VARCHAR(200) | - | NULL | 行业 |
| officeCode | VARCHAR(50) | - | NULL | 办事处编码 |
| officeName | VARCHAR(200) | - | NULL | 办事处名称 |
| officeCodes | VARCHAR(500) | - | NULL | 办事处权限编码列表 |
| salesman | VARCHAR(100) | - | NULL | 销售人员 |
| salesmanLink | VARCHAR(100) | - | NULL | 销售联系方式 |
| productManager | VARCHAR(100) | - | NULL | 产品经理 |
| serviceManager | VARCHAR(100) | - | NULL | 服务经理编码 |
| serviceManagerName | VARCHAR(200) | - | NULL | 服务经理姓名 |
| projectManager | VARCHAR(100) | - | NULL | 项目经理编码 |
| projectManagerName | VARCHAR(200) | - | NULL | 项目经理姓名 |
| oldProjectManager | VARCHAR(100) | - | NULL | 原项目经理编码 |
| lendInfoId | VARCHAR(100) | - | NULL | SMS借货主键ID |
| lendfiles | VARCHAR(500) | - | NULL | 借货交付件 |
| hasRma | VARCHAR(10) | - | NULL | 是否存在未核销数据 |
| hasTransfer | VARCHAR(10) | - | NULL | 是否存在借转销数据 |
| source | VARCHAR(50) | - | NULL | 数据来源 |
| closeRemark | TEXT | - | NULL | 关闭备注 |
| confirmFileIds | VARCHAR(500) | - | NULL | 现场测试确认单文件ID列表 |
| finshedTime | DATETIME | - | NULL | 项目完成测试时间 |
| quesnaireId | INT | - | 0 | 回访问卷ID |
| quesnaireState | INT | - | 0 | 问卷状态 |
| customInfo | JSON | - | NULL | 自定义扩展信息（JSON格式） |
| createBy | VARCHAR(100) | - | NULL | 创建人 |
| createTime | DATETIME | - | NULL | 创建时间 |
| updateBy | VARCHAR(100) | - | NULL | 更新人 |
| updateTime | DATETIME | - | NULL | 更新时间 |
| effectiveFrom | DATETIME | - | NULL | 生效开始时间 |
| effectiveTo | DATETIME | - | NULL | 生效结束时间 |

**项目状态流转：**
- 30: 创建中 → 31: 审批中 → 32: 测试中 → 33: 已完成
- 特殊状态：闭环(闭环完成)、拒绝(审批拒绝)

---

## 2. pm_presales_project_product_line（售前项目产品线表）

售前项目产品明细表，记录售前项目关联的产品信息。

| 字段名 | 类型 | 约束 | 默认值 | 业务含义 |
|--------|------|------|--------|----------|
| productLineId | INT | PK, AUTO_INCREMENT | - | 明细表主键 |
| presalesId | INT | NOT NULL, FK | - | 售前项目ID，关联pm_presales_project_header.presalesId |
| productFirstName | VARCHAR(200) | - | NULL | 产品一级分类 |
| productTypeName | VARCHAR(200) | - | NULL | 产品类型 |
| itemCode | VARCHAR(100) | - | NULL | 产品编码 |
| itemModel | VARCHAR(200) | - | NULL | 产品型号 |
| itemDesc | VARCHAR(500) | - | NULL | 产品描述 |
| price | DECIMAL(18,2) | - | 0 | 目录价 |
| productNum | INT | - | 0 | 数量 |
| transferNum | INT | - | 0 | 借转销数量 |
| hexiaoNum | INT | - | 0 | 核销数量 |
| remark | VARCHAR(500) | - | NULL | 备注 |
| createBy | VARCHAR(100) | - | NULL | 创建人 |
| createTime | DATETIME | - | NULL | 创建时间 |

---

## 3. pm_presales_project_callback（售前项目回访表）

售前项目回访记录表，记录回访问卷信息。

| 字段名 | 类型 | 约束 | 默认值 | 业务含义 |
|--------|------|------|--------|----------|
| id | INT | PK, AUTO_INCREMENT | - | 主键ID |
| presalesId | INT | NOT NULL, FK | - | 售前项目ID |
| quesnaireId | INT | - | NULL | 问卷模板ID |
| callbackState | INT | - | 0 | 回访状态（0:未回访 1:已回访） |
| callbackBy | VARCHAR(100) | - | NULL | 回访人 |
| callbackTime | DATETIME | - | NULL | 回访时间 |
| callbackRemark | TEXT | - | NULL | 回访备注 |
| createBy | VARCHAR(100) | - | NULL | 创建人 |
| createTime | DATETIME | - | NULL | 创建时间 |

---

## 4. pm_presales_project_duration（售前项目耗时表）

售前项目各阶段耗时统计表。

| 字段名 | 类型 | 约束 | 默认值 | 业务含义 |
|--------|------|------|--------|----------|
| id | INT | PK, AUTO_INCREMENT | - | 主键ID |
| presalesId | INT | NOT NULL, FK | - | 售前项目ID |
| stageCode | VARCHAR(50) | NOT NULL | - | 阶段编码 |
| stageName | VARCHAR(200) | - | NULL | 阶段名称 |
| startTime | DATETIME | - | NULL | 阶段开始时间 |
| endTime | DATETIME | - | NULL | 阶段结束时间 |
| duration | VARCHAR(100) | - | NULL | 耗时（格式化字符串） |
| createBy | VARCHAR(100) | - | NULL | 创建人 |
| createTime | DATETIME | - | NULL | 创建时间 |

**阶段编码说明：**

| 阶段 | 含义 |
|------|------|
| applyDuration | 项目同步到项目开始的时间间隔 |
| totalDuration | 项目开始到结束的时间间隔 |
| serviceDuration | 指派服务经理的时间耗时 |
| programDuration | 指派项目经理的时间耗时 |
| testDuration | 跟踪测试的时间耗时 |
| callbackDuration | 回访的时间耗时 |
| serviceApproveDuration | 服务经理审批的时间耗时 |

---

## 5. pm_presales_project_rma_info（售前项目RMA信息表）

售前项目RMA（退货授权）信息表，记录借转销和RMA核销数据。

| 字段名 | 类型 | 约束 | 默认值 | 业务含义 |
|--------|------|------|--------|----------|
| id | INT | PK, AUTO_INCREMENT | - | 主键ID |
| presalesId | INT | NOT NULL, FK | - | 售前项目ID |
| rmaNo | VARCHAR(100) | - | NULL | RMA单号 |
| barCode | VARCHAR(100) | - | NULL | 设备序列号 |
| itemCode | VARCHAR(100) | - | NULL | 产品编码 |
| itemModel | VARCHAR(200) | - | NULL | 产品型号 |
| itemName | VARCHAR(500) | - | NULL | 产品名称 |
| rmaType | VARCHAR(50) | - | NULL | RMA类型 |
| rmaState | VARCHAR(50) | - | NULL | RMA状态 |
| contractNo | VARCHAR(200) | - | NULL | 合同号 |
| createBy | VARCHAR(100) | - | NULL | 创建人 |
| createTime | DATETIME | - | NULL | 创建时间 |

---

## 表间关系概览

```
pm_presales_project_header (1) ──→ (N) pm_presales_project_product_line  通过 presalesId
pm_presales_project_header (1) ──→ (N) pm_presales_project_callback     通过 presalesId
pm_presales_project_header (1) ──→ (N) pm_presales_project_duration     通过 presalesId
pm_presales_project_header (1) ──→ (N) pm_presales_project_rma_info     通过 presalesId

pm_presales_project_header ──→ pm_project_member  通过 presalesId(projectId)
                            （售前项目也使用pm_project_member表管理成员）

pm_presales_project_header ──→ pm_project_header  通过 projectCode
                            （售前项目可关联到售后项目）
```
